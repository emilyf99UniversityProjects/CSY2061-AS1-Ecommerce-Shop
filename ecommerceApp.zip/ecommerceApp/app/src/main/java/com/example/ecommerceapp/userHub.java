package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
/**
 * File Name: userHub.java
 * Purpose: Activity that allows user login
 * Activity Order: U.2
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class userHub extends AppCompatActivity {
    Spinner categorySelect;
    //used for testing
    //TextView loadTest;
    ListView productList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_hub);
        categorySelect = (Spinner) findViewById(R.id.spinner);
        productList = (ListView) findViewById(R.id.products);

        //calls the basket file function so basket file is ready on activity launch
        try {
            createBasketFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        setTitle("Choose Products");
        //used to get the files needed for the category spinner
        getFiles();
    }

    //When the user clicks the checkout button the next acitvity is created
    public void openBasket(View view){
        Intent openBasket = new Intent(this, completeBasket.class);
        startActivity(openBasket);

    }

    //used to set spinner
    //saves all the files in the directory as a string
    //takes the string into an array list
    //loops though a for loop on the string and adds the value to the list.
    //list is then added to spinner
    public void getFiles() {
        String[] filename = getApplicationContext().fileList();
        List<String> list = new ArrayList<String>();
        for(int i =0; i<filename.length; i++){
            //Log.d("Filename", filename[i]);
            list.add(filename[i]);
        }
        ArrayAdapter<String> filenameAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,list);
        categorySelect.setAdapter(filenameAdapter);

    }

    //called when view products is clicked
    public void loadProducts(View v) {
        //takes the spinner file name and converts it to a string
        String filename = categorySelect.getSelectedItem().toString();
        //Used to test file retrieval
        //loadTest.setText(fileTitle);


        //takes the values of the category file and turns it into a list
        //then passes the value into the create array function
        FileInputStream fis = null;
        try {
            fis = openFileInput(filename);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text;
            while ((text = br.readLine()) != null) {
                sb.append(text).append("\n");
            }
            String s = sb.toString();
            createArray(s);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    //used to turn a string into an array
    //creates new arraylist and saves values into it, splits where there is a new line escape case
    public void createArray(String s){

        ArrayList<String> products = new ArrayList<String>(Arrays.asList(s.split("\n")));

        ListAdapter listAdapter = new ListAdapter(userHub.this, (ArrayList<String>) products);
        productList.setAdapter(listAdapter);

    }

    //when see previous orders is clicked, opens the next acitivty
    public void openPreviousOrders(View view){
        Intent previousOrders = new Intent(this, previousOrders.class);
        startActivity(previousOrders);
    }

    //creates the basket file so that users can save what they want to buy
    public void createBasketFile() throws IOException {
        //gets directory and combines it with a string to get directory and file list
        File dir = getFilesDir();
        String basketFileName = "basket.txt";
        File basketFile = new File(dir, basketFileName);
        basketFile.createNewFile();
        //uscd to test if file is created when page is loaded
        //Toast.makeText(this, "File Created: " + basketFile, Toast.LENGTH_SHORT).show();

    }

    //when add to basket button is clicked the value on that row is added to the basket text file
    //custom layout views are used to achieve this.
    public static void addToBasket(String product, View view){
        //get value from row clicked
        //add it to the file
        FileOutputStream fos = null;
        String filename = "basket.txt";
        try {
            fos = view.getContext().openFileOutput(filename, MODE_APPEND);
            fos.write(product.getBytes(StandardCharsets.UTF_8));

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }

    }

}