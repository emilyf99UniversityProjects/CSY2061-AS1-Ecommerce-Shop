package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
/**
 * File Name: adminProductMenu.java
 * Purpose: (Not Implemented) Would be used to edit a product title for updates or to correct error
 * Activity Order: A.3.PM.2
 * Author: Emily Fletcher
 * Student Number: 18410839
 */

//this function has not been implemented but remains so full app navigation can be achieved
public class editSingleProductMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_single_product_menu);
    }
}