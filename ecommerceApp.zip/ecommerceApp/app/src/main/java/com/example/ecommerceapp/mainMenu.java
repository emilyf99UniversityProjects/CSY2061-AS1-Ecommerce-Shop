package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/**
 * File Name: login.java
 * Purpose: Allows the option for a User Login and a Admin Login
 * Activity Order: 1
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class mainMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);
        setTitle("Login");
    }

    //takes user to admin login
    public void adminLoginClicked(View view){
        Intent hub = new Intent(this, adminLogin.class);
        startActivity(hub);
    }

    //takes user to user login
    public void userLoginClicked(View view){
        Intent hub = new Intent(this, login.class);
        startActivity(hub);
    }
}