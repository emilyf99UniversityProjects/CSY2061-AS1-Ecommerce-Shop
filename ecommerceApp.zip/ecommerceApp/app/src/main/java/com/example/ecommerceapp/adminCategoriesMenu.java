package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/**
 * File Name: adminCategories.java
 * Purpose: Allows admin to add categories, refresh the category list, and clear the list completely
 * Activity Order: A.3.CM.0
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class adminCategoriesMenu extends AppCompatActivity {

    Button saveCategory;
    Button loadCategory;
    EditText inputCategory;
    TextView showCategories;
    String filename = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_categories_menu);
        saveCategory = (Button) findViewById(R.id.addCategoryButton);
        loadCategory = (Button) findViewById(R.id.refreshCategoryButton);
        inputCategory = (EditText) findViewById(R.id.addCategory);
        showCategories = (TextView) findViewById(R.id.categoryList);

        //sets the filename
        filename = "categoryList";

        setTitle("Categories Menu");
    }

    //called when the add button is clicked
    public void addCategory(View v) {
        //gets the user input and converts it to a string
        String text = inputCategory.getText().toString() + "\n";
        FileOutputStream fos = null;
        try {
            //grabs the file and sets it to append so new objects can be added tothe end
            fos = openFileOutput(filename, MODE_APPEND);
            fos.write(text.getBytes(StandardCharsets.UTF_8));

            //Toast message to allow the user to see where the file has been saved
            Toast.makeText(this, "Saved to " + getFilesDir() + "/" + filename, Toast.LENGTH_LONG).show();

            //clears the input box to avoid duplication
            inputCategory.getText().clear();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }

    }

    //called when the reload button is clicked
    public void reloadCategoryList(View v) {
        FileInputStream fis = null;
        try {
            fis = openFileInput(filename);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text;
            while ((text = br.readLine()) != null) {
                sb.append(text).append("\n");
            }
            showCategories.setText(sb.toString());
            turnintoarray();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    //called when the clear button is clicked
    public void clearCategoryList(View v) {
        //getting the file directory
        File dir = getFilesDir();
        //setting th file path of directory and the name set in global
        File category = new File(dir, filename);
        //sets to true and deletes content
        boolean deleted = category.delete();
        //toast to let user know the file has been wiped
        Toast.makeText(this, "Category Deleted " + getFilesDir() + "/" + filename, Toast.LENGTH_LONG).show();
        //hides the list of categories as the list will not update until another element is added
        showCategories.setText("");
    }

    //gets a file and turns it into an array
    public void turnintoarray() throws IOException {

        //setting the file names and directory
        File dir = getFilesDir();
        File category = new File(dir, filename);

        //takes content of the file and creates a string buildler
        //the string found by the string builder is added to the arraylist
        //new line is used at the end to seperate the values in the list.
        //value is passed to create file function
        ArrayList<String> categories = new ArrayList<String>();
        Scanner in = new Scanner(category);
        while (in.hasNextLine()) {
            categories.add(in.nextLine());
        }
        Collections.sort(categories);
        StringBuilder categoryList = new StringBuilder();
        for (String s : categories) {
            categoryList.append(s + "\n");
            createFile(s);
        }

    }

    //used to create files for each element in the list array
    //these files are created to store products into them
    public void createFile(String s) throws IOException {
        //gets the directory and file name
        //uses these values to create a new value
        File dir = getFilesDir();
        String catFilename = s + ".txt";
        File category = new File(dir, catFilename);
        category.createNewFile();

        //lets the user know the file has been created
        Toast.makeText(this, "File Created: " + dir + "/" + catFilename, Toast.LENGTH_SHORT).show();

    }

    //when the advanced menu button is clicked the advanced menu is called
    public void openAdvancedCategoriesMenu(View viw){
        Intent advancedCategoriesMenu = new Intent(this, advancedMenuCategories.class);
        startActivity(advancedCategoriesMenu);
    }
}
