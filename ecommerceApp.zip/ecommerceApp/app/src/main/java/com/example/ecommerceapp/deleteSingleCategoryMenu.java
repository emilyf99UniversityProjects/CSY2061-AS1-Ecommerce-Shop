package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/**
 * File Name: editSingleCategoryMenu.java
 * Purpose: Allows (Not Implemented) This would allow a user to remove an element
 *          from the categoryList
 * Activity Order: A.3.CM.3
 * Author: Emily Fletcher
 * Student Number: 18410839
 */

//this function has not been implemented and remains as navigation completion
public class deleteSingleCategoryMenu extends AppCompatActivity {
    Button deleteButton;
    EditText userInput;
    TextView categoryList;
    List<String> list = new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_single_category_menu);
        deleteButton = (Button) findViewById(R.id.deleteCategoryButton);
        userInput = (EditText) findViewById(R.id.deleteCategorySingleInput);
        categoryList = (TextView) findViewById(R.id.categoryListDeleteSingle);

        setTitle("Delete a Category");
        //call to get the current list file
        getCategoryList();
    }

    public void getCategoryList(){
        //sets filename
        String filename = "categoryList";
        FileInputStream fis = null;
        //attempts to turn the file into value of lists
        // sets it as a text view so user can see list
        try {
            fis = openFileInput(filename);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text;
            while ((text = br.readLine()) != null) {
                sb.append(text).append("\n");
            }
            categoryList.setText(sb.toString());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    //when the delete button is clicked
    public void deleteClicked(View view){
        //users written input is turned into a string and
        //category list is turned into a string and then into an array list with new line as split point
        String records = categoryList.getText().toString();
        List<String> recordsList = new ArrayList<String>(Arrays.asList(records.split("\n")));
        String input = userInput.getText().toString();

        //loops over the arrayList
        for(int i = 0; i < recordsList.size(); i++){
            //if a record is found that equals the input it is removed
                if(recordsList.get(i).equals(input)) {
                recordsList.remove(i);

            }
                //if a record matching is not found then a not found toast is displayed
            else {
                Toast.makeText(this, "No Category Found", Toast.LENGTH_LONG).show();
            }
        }
        //text view is updated with new list
        categoryList.setText(records);
    }

}