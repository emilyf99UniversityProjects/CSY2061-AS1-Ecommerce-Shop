package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
/**
 * File Name: saveOrderToFile.java
 * Purpose: Allows the user to save a file with their orders saved under the name of their
 *          email address
 * Activity Order: U.5
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class saveOrderToFile extends AppCompatActivity {

    Button saveToEmail;
    EditText userEmail;
    TextView basket;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save_order_to_file);
        setTitle("Save Order To File");
        saveToEmail = (Button) findViewById(R.id.saveOrderButton);
        userEmail  = (EditText) findViewById(R.id.emailAddressToSave);
        basket = (TextView) findViewById(R.id.basketContent);

        //called to get the basket file
        getBasket();
    }

    //called when the save button is clicked
    //creates a file that has the same name as the email entered by the user
    //passes a date variable that gets the time the file is created
    //gets the file name from the value inputted by the user
    public void createFile(View view) throws IOException {
        Date currentTime = Calendar.getInstance().getTime();
        File dir = getFilesDir();
        String emailString = userEmail.getText().toString();
        String emailFilename = emailString + ".txt";
        File email = new File(dir, emailFilename);
        email.createNewFile();
        //toast message is created so user knows the file has  been created
        Toast.makeText(this, "File Created: " + dir + "/" + emailFilename, Toast.LENGTH_SHORT).show();
        //pass the name and time to the addContents function so that it can  be saved into the basket
        addContents(emailFilename, currentTime);
    }

    //retrieve the basket file and sets it to a TextView so the user can see it
    public void getBasket() {
        FileInputStream fis = null;
        String filename = "basket.txt";
        try {
            fis = openFileInput(filename);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text;
            while ((text = br.readLine()) != null) {
                sb.append(text).append("\n");
            }
            String s = sb.toString();
            basket.setText(s);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    //adds the contents to the relevant file
    public void addContents(String emailFilename, Date currentTime){

        //changes the datae created into a format and then sets it to a string
        DateFormat timeFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
        String dateString= timeFormat.format(currentTime);
        //gets the basket text
        String orderContent = basket.getText().toString();

        //collates time, and content together the create a record of the order
        String text = "Order" + "\n" + "Time Saved: " + dateString + "\n"
                +orderContent + "\n";
        FileOutputStream fos = null;

        //tries to append the email file and add the new record into it
        try {
            fos = openFileOutput(emailFilename, MODE_APPEND);
            fos.write(text.getBytes(StandardCharsets.UTF_8));
            Toast.makeText(this, "Saved to " + getFilesDir() + "/" + emailFilename, Toast.LENGTH_LONG).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }

    }

}