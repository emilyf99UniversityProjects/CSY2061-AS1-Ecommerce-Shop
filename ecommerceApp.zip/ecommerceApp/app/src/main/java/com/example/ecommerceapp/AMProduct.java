package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/**
 * File Name: adminProductMenu.java
 * Purpose: Allows admin to navigate to editing a product, deleting a product,
 *          or returning to admin menu
 * Activity Order: A.3.PM.1
 * Author: Emily Fletcher
 * Student Number: 18410839
 */

public class AMProduct extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amproduct);
        setTitle("Advanced Menu : Products");
    }

    //when edit button is clicked activity is called
    public void openEditProductOption(View view){
        Intent openEditProduct = new Intent(this, editSingleProductMenu.class);
        startActivity(openEditProduct);
    }

    //when delete button is clicked activity is called
    public void openDeleteProductOption(View view){
        Intent openDeleteProduct = new Intent(this, deleteSingleProductMenu.class);
        startActivity(openDeleteProduct);
    }

    //when return button is clicked user is returned to main admin menu
    public void returnToAdminMenuOption(View view){
        Intent returnToAdminMenu = new Intent(this, adminHub.class);
        startActivity(returnToAdminMenu);
    }

}