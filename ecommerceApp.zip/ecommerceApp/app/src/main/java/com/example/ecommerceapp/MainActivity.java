package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * File Name: MainActivity.java
 * Purpose: Generates a splash screen for when the app opens
 * Activity Order: 0
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class MainActivity extends AppCompatActivity {

    //timer for the splash screen, set to three seconds
    final int SPLASH = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //hides the action bar so that only the splash screen is seen
        getSupportActionBar().hide();

        //clears the basket so when the user restarts the app the basket is empty
        clearBasket();

        //Handler delays the call of the next activity to give the user time to read the splashscreen
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent mainMenu = new Intent(MainActivity.this, mainMenu.class);
                startActivity(mainMenu);
                finish();
            }

        }, SPLASH);
    }

    public void clearBasket() {

        //Set to empty string, overwrites current basket contents
        String reset = " ";
        FileOutputStream fos = null;
        //finds basket file
        String filename = "basket.txt";
        try {
            //mode private so that file is overwritten rather than amended.
            fos = openFileOutput(filename, MODE_PRIVATE);
            fos.write(reset.getBytes(StandardCharsets.UTF_8));

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }
    }
}