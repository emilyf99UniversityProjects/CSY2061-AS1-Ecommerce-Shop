package com.example.ecommerceapp;

import static android.content.Context.MODE_APPEND;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
/**
 * File Name: ListAdapter.java
 * Purpose: Allows for a custom viewList, is used as an additional feature to show a deeper
 *          understanding of custom layouts in andorid studio
 * Activity Order: E.0
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class ListAdapter extends BaseAdapter {
    Context context;
    ArrayList<String> stringArrayList;
    LayoutInflater layoutInflater;

    //initial creation of a list adapter and constructor values
    public ListAdapter(Context contextAA, ArrayList<String> stringArrayListAA) {
        this.context = contextAA;
        this.stringArrayList = stringArrayListAA;
        layoutInflater = LayoutInflater.from(contextAA);

    }
    //gets for the custom list adapter, all return values from the adapter
    //View get view is used to implement the layout of the custom adapter
    //adds name and button to layout and when called adds  it to the basket using onClick
    @Override
    public int getCount() {
        return stringArrayList.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View productsView = layoutInflater.inflate(R.layout.product_view_layout,viewGroup,false);
        TextView productName;
        Button basketButton;
        productName = (TextView) productsView.findViewById(R.id.productName);
        basketButton= (Button) productsView.findViewById(R.id.addToBasketButton);
        productName.setText(stringArrayList.get(i));
        basketButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //get value of field
                //add value to basket file

                String product = productName.getText().toString() + "\n";
                userHub.addToBasket(product, view);

            }
        });
        //return statement is needed to return the view so it is displayed
        //for each call the row defined in View is used.
        return productsView;
    }


}

