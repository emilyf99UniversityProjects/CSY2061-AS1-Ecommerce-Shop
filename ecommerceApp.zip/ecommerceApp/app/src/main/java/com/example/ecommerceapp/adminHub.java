
package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/**
 * File Name: adminHub.java
 * Purpose: Allows an admin select the categories menu, products menu or tutorial
 * Activity Order: A.2
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class adminHub extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_hub);
        setTitle("Admin HomePage");
    }

    //when button clicked, opens the admin categories
    public void openAdminCategoriesMenu(View view){
        Intent adminCategories = new Intent(this, adminCategoriesMenu.class);
        startActivity(adminCategories);
    }

    //when button clicked, opens the products menu
    public void openAdminProductsMenu(View view){
        Intent adminProducts = new Intent(this, adminProductMenu.class);
        startActivity(adminProducts);
    }

    //add tutorial buutton code
    //starts admin tutorial
}