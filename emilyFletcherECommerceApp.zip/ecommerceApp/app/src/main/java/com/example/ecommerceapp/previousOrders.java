package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
/**
 * File Name: previousOrders.java
 * Purpose: Shows the user all the orders they have made with a specific email address
 * Activity Order: U.7
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class previousOrders extends AppCompatActivity {

    TextView email;
    TextView previousOrders;
    Button seeOrders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_previous_orders);
        setTitle("Previous Orders");
        email = (TextView) findViewById(R.id.userEmail);
        previousOrders = (TextView) findViewById(R.id.previousOrders);
        seeOrders = (Button) findViewById(R.id.seePreviousOrders);

    }

    //called when see orders button is pressed
    public void getOrderHistory(View view) {
        FileInputStream fis = null;

        //takes the users inputted email and sets it to a string value with an extension for the file name
        String filename = email.getText().toString() + ".txt";
        //attempts to open a file with a name that matches the email sent
        //opens every order stored within that Textfile as  new order and adds it too a text view

        try {
            fis = openFileInput(filename);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text;
            while ((text = br.readLine()) != null) {
                sb.append(text).append("\n");
            }
            String s = sb.toString();
            previousOrders.setText(s);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
}}