package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
/**
 * File Name: deleteSingleCategoryMenu.java
 * Purpose: (Not Implemented) Would allow the admin to take a value from the list and
 *          update it/ correct it
 * Activity Order: A.3.CM.3
 * Author: Emily Fletcher
 * Student Number: 18410839
 */

//this function has not been implemented but remains so full app navigation can be achieved
public class deleteSingleProductMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_single_product_menu);
        setTitle("Delete a Product");
    }
}