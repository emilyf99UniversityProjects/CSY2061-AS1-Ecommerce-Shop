package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import java.util.Calendar;
import java.util.Date;
/**
 * File Name: checkoutsplash.java
 * Purpose: Shows splash message thanking the user for their order and gives the option
 *          to save receipt or email it
 * Activity Order: U.4
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class checkoutsplash extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkoutsplash);
        setTitle("Checkout Complete");

    }

    //when the save receipt button is clicked, next activity is called.
    public void saveToFileButton(View view){
        Intent saveToFile = new Intent(this, saveOrderToFile.class);
        startActivity(saveToFile);

    }

    //when the email receipt button is pressed, next activity is called
    public void emailReceipt(View view){
        Intent sendEmail = new Intent(this, emailReceipt.class);
        startActivity(sendEmail);
    }


}