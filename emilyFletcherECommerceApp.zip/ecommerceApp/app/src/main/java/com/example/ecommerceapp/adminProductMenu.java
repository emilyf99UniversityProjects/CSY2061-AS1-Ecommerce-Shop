package com.example.ecommerceapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * File Name: adminProductMenu.java
 * Purpose: Allows admin to add products to a specific category file, refresh the product list,
 *          and clear the list completely
 * Activity Order: A.3.PM.0
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class adminProductMenu extends AppCompatActivity {

    Button saveProduct;
    Button loadProduct;
    Spinner category;
    EditText inputProduct;
    TextView showProducts;
    String filename = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_product_menu);

        saveProduct = (Button) findViewById(R.id.createProduct);
        loadProduct = (Button) findViewById(R.id.reloadProducts);
        category = (Spinner) findViewById(R.id.categorySpinner);
        inputProduct = (EditText) findViewById(R.id.productInput);
        showProducts = (TextView) findViewById(R.id.currentProducts);
        setTitle("Products Menu");

        //on creation calls the get files function, this fetches all the category files
        getFiles();
    }

    public void getFiles() {
        String[] filename = getApplicationContext().fileList();
        List<String> list = new ArrayList<String>();

        //for loop is used to iterate over complete list of files within directory
        //they are then added to the spinner
        for(int i =0; i<filename.length; i++){
            //log used for testing name was being created correctly
            //Log.d("Filename", filename[i]);
            list.add(filename[i]);
        }
        ArrayAdapter<String> filenameAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,list);
        category.setAdapter(filenameAdapter);
    }

    //called when the create product button is clicked
    public void addProduct(View v) {
        //gets user input and turns it into a string
        String text = inputProduct.getText().toString() + "\n";
        FileOutputStream fos = null;

        //sets teh file to the category selected by the spinner
        filename = category.getSelectedItem().toString();
        try {
            fos = openFileOutput(filename, MODE_APPEND);
            fos.write(text.getBytes(StandardCharsets.UTF_8));
            //toast message to let the user know where the product was saved too
            Toast.makeText(this, "Saved to " + getFilesDir() + "/" + filename, Toast.LENGTH_LONG).show();
            inputProduct.getText().clear();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }

    }

    //called when reload is pressed
    //sets the user input box to empty
    //sets the TextView to the contents of the current category and opens the file
    public void reloadProductList(View v) {
        inputProduct.setText("");
        String selectFile = String.valueOf(category.getSelectedItem());
        openFile(selectFile);

    }

    //used to find and open the file
    //uses a stringbuilder to set the contents of the file into a list
    public void openFile(String selectFile){

        FileInputStream fis = null;

        try {
            fis = openFileInput(filename);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text;
            while ((text = br.readLine()) != null) {
                sb.append(text).append("\n");
            }
            showProducts.setText(sb.toString());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }}

    //called when clear button is pressed
    //gets the file directory and file location
    //sets a toast that lets you know that the file has been deleted
    //sets the products text view to empty string so that the user is not confused and thinks the
    //file is still there after deletion
    public void clearProductist(View v) {
        File dir = getFilesDir();
        File category = new File(dir, filename);
        boolean deleted = category.delete();
        Toast.makeText(this, "Category Deleted " + getFilesDir() + "/" + filename, Toast.LENGTH_LONG).show();
        showProducts.setText("");
    }

    //when the advanced products menu button is clicked the next activity opens
    public void openAdvancedProductsMenu(View view){
        Intent openAdvancedProducts = new Intent(this, AMProduct.class);
        startActivity(openAdvancedProducts);
    }
}