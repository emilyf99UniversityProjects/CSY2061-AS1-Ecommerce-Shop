package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

/**
 * File Name: adminlogin.java
 * Purpose: Allows an admin to login
 * Activity Order: A.1
 * Author: Emily Fletcher
 * Student Number: 18410839
 */

public class adminLogin extends AppCompatActivity {

    EditText adminUsernameIn;
    EditText adminPasswordIn;
    TextView status;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);
        setTitle("Admin Login");
        adminUsernameIn = (EditText) findViewById(R.id.adminUsernameInput);
        adminPasswordIn = (EditText) findViewById(R.id.adminUserPasswordInput);
        status = (TextView) findViewById(R.id.adminLoginStatus);
        submit = (Button) findViewById(R.id.AdminSubmitButton);
    }

    public void checkAdminLogin(View view){
        //current size of array that holds accounts, currently stores 3 unique accounts
        final int SIZE = 2;
        String usernames[] = {"Super", "TestAdmin", "TestAdmin2"};
        String passwords[] = {"Password", "Password1", "Password2"};

        //converts user inputs to strings that can be used for comparisons
        String userUsername = adminUsernameIn.getText().toString();
        String userPassword = adminPasswordIn.getText().toString();

        //For loop loops over the entire contents of array
        for(int i = 0; i < SIZE; i++){

            //if a match is found then open the user menu activity and notify the user
            // with a toast message, breaks after to stop second toast message appearing
            if(userUsername.equals(usernames[i]) && userPassword.equals(passwords[i])) {
                Toast.makeText(this, "Username and Password is Correct", Toast.LENGTH_SHORT).show();
                openAdminHub();
                break;
            }

            //if match not found let user know the details entered were incorrect
            else {
                Toast.makeText(this, "Incorrect Username or Password, Please try again", Toast.LENGTH_SHORT).show();
            }
        }

    }
    //opens admin menu
    public void openAdminHub(){
        Intent adminHub = new Intent(this, adminHub.class);
        startActivity(adminHub);
    }
}