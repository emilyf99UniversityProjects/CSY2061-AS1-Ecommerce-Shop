package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/**
 * File Name: ammendBasket.java
 * Purpose: Would allow the user to delete elements from the basket
 * Activity Order: U.7
 * Author: Emily Fletcher
 * Student Number: 18410839
 */


//this function has not been implemented and remains as navigation completion
public class ammendBasket extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ammend_basket);
        setTitle("Ammend Basket");
    }

    public void returnButton (View view){
        Intent returnToBasket = new Intent(this, completeBasket.class);
        startActivity(returnToBasket);
    }
}