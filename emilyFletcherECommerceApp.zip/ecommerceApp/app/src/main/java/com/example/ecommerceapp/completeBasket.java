package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Random;
/**
 * File Name: completeBasket.java
 * Purpose: Shows basket with the options to check out or add mystery gift
 * Activity Order: U.3
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class completeBasket extends AppCompatActivity {
    TextView currentBasket;
    Button mysteryGift;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_complete_basket);
        currentBasket = (TextView) findViewById(R.id.shoppingList);
        mysteryGift = (Button) findViewById(R.id.mysteryGiftButton);
        setTitle("Check Out");

        //used to check for android versions newer or equal to oreo
        //if newer channels are set for notification in order for it to work on newer devices
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("orderSuccessful",
                    "Order Successful", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
        //gets basket file
        getBasket();
    }
    //if check out button is pressed, next activity is called
    public void checkout(View view){
        Intent thankYouMessage = new Intent(this, checkoutsplash.class);
        startActivity(thankYouMessage);
        //calls the notification function
        orderNotification();
    }

    //searches for the basket file
    //string builder takes the values of the file and splits them into a list when there is
    //a new line
    //sets these list values to the textview of the shopping basket
    public void getBasket(){
        String filename = "basket.txt";
        FileInputStream fis = null;
        try {
            fis = openFileInput(filename);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text;
            while ((text = br.readLine()) != null) {
                sb.append(text).append("\n");
            }
            currentBasket.setText(sb.toString());
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    //used to set a push notification for when the checkout button is pressed
    public void orderNotification(){
        //creation the notification and its channel
        NotificationCompat.Builder builder = new NotificationCompat.Builder
                (completeBasket.this, "orderSuccessful");
        //setting the notification title and content
        builder.setContentTitle("Order Success");
        builder.setContentText("Your order has been successful, thank you for ordering with us");
        //icon set for notification
        builder.setSmallIcon(R.drawable.ic_launcher_background);
        //set to false so notification stays and the user has to wipe it manually
        builder.setAutoCancel(false);

        NotificationManagerCompat managerCompat = NotificationManagerCompat.from(completeBasket.this);
        managerCompat.notify(1, builder.build());
    }

    //used to demonstrate randoms
    //is not seen on this shopping list but the next one to minimise risk of redoing the funciton
    public void mysteryGift(){
        //array of possible gifts
        String gifts[] = {"10% Off Next Order", "Free Sticker", "Free Slime", "20% Off Next Order",
        "Haribo StarMix Tub", "25% Off Next Order", "Free Postage Next Order"};

        //size is set the maximum size of the array
        final int SIZE = gifts.length;

        //creates a new random and then randomises a value between the next int and the size
        //then creates a string with that value and an identifier added so when the customer views
        //the basket they can easily identify which product is the gift.
        Random rand = new Random();
        int giftSelector = rand.nextInt(SIZE) + 1;
        String freegift = "(Mystery Gift)" + gifts[giftSelector] + "\n";

        //appends the mystery gift to the basket text file
        FileOutputStream fos = null;
        String filename = "basket.txt";
        try {
            fos = openFileOutput(filename, MODE_APPEND);
            fos.write(freegift.getBytes(StandardCharsets.UTF_8));

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }

    }

    //called when add mystery gift is clicked
    //calls mystery gift function and then disables the button so multiple can't be added
    public void addMysteryGift(View view){
        mysteryGift();
        mysteryGift.setEnabled(false);
    }

    //when ammend button is clicked new activity is called
    public void ammendBasket(View view){
        Intent ammend = new Intent(this, ammendBasket.class);
        startActivity(ammend);
    }








}