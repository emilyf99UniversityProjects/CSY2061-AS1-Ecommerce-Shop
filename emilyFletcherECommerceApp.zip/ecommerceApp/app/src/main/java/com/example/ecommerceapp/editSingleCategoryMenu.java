package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
/**
 * File Name: editSingleCategoryMenu.java
 * Purpose: (Not Implemented) Would allow the admin to take a value from the list and
 *          update it/ correct it
 * Activity Order: A.3.CM.2
 * Author: Emily Fletcher
 * Student Number: 18410839
 */

//this function has not been implemented and remains as navigation completion
public class editSingleCategoryMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_single_category_menu);
        setTitle("Edit a Category");
    }
}