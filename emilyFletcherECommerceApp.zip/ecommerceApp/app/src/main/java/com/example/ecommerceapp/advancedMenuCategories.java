package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/**
 * File Name: advancedMenuCatagories.java
 * Purpose: Allows an admin select the categories menu, products menu or tutorial
 * Activity Order: A.3.CM.1
 * Author: Emily Fletcher
 * Student Number: 18410839
 */

public class advancedMenuCategories extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced_menu_categories);
        setTitle("Advanced Menu: Categories");
    }

    //when edit button clicked opens edit menu
    public void openEditCategoryOption(View view){
        Intent openEditCategory = new Intent(this, editSingleCategoryMenu.class);
        startActivity(openEditCategory);
    }

    //when delete button clicked opens delete menu
    public void openDeleteCategoryOption(View view){
        Intent openDeleteCategory = new Intent(this, deleteSingleCategoryMenu.class);
        startActivity(openDeleteCategory);
    }

    //when return button clicked, takes user back to admin hub
    public void returnToAdminMenuOption(View view){
        Intent returnToAdminMenu = new Intent(this, adminHub.class);
        startActivity(returnToAdminMenu);
    }
}