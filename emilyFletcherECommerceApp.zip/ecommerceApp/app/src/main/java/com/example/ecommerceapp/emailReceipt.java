package com.example.ecommerceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
/**
 * File Name: emailReceipt.java
 * Purpose: Opens the users email client and sets up an email for them to
 *          send to themselves
 * Activity Order: U.6
 * Author: Emily Fletcher
 * Student Number: 18410839
 */
public class emailReceipt extends AppCompatActivity {
    Button sendEmail;
    EditText userEmail;
    TextView basket;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email_receipt);
        setTitle("Send Email Reciept");
        sendEmail = (Button) findViewById(R.id.sendEmailButton);
        userEmail = (EditText) findViewById(R.id.userEmailAddress);
        basket = (TextView) findViewById(R.id.basketOrder);
        //gets basketFile
        getBasket();

    }
    //create email file, duplicate code from saveOrderToFile
    //is needed for viewing previous orders
    public void createFile() throws IOException {
        Date currentTime = Calendar.getInstance().getTime();
        File dir = getFilesDir();
        String emailString = userEmail.getText().toString();
        String emailFilename = emailString + ".txt";
        File email = new File(dir, emailFilename);
        email.createNewFile();
        Toast.makeText(this, "File Created: " + dir + "/" + emailFilename, Toast.LENGTH_SHORT).show();
        addContents(emailFilename, currentTime);

    }
    public void addContents(String emailFilename, Date currentTime){
        //get text content from view

        DateFormat timeFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
        String dateString= timeFormat.format(currentTime);
        String orderContent = basket.getText().toString();


        String text = "Order" + "\n" + "Time Saved: " + dateString + "\n"
                +orderContent + "\n";
        FileOutputStream fos = null;

        try {
            fos = openFileOutput(emailFilename, MODE_APPEND);
            fos.write(text.getBytes(StandardCharsets.UTF_8));
            Toast.makeText(this, "Saved to " + getFilesDir() + "/" + emailFilename, Toast.LENGTH_LONG).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        }

    }

    public void getBasket(){
        FileInputStream fis = null;
        String filename = "basket.txt";
        try {
            fis = openFileInput(filename);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text;
            while ((text = br.readLine()) != null) {
                sb.append(text).append("\n");
            }
            String s = sb.toString();
            basket.setText(s);


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    //creates the file linked to email

    public void send(View view) throws IOException {
        createFile();
        String userEmailString;
        String subject;
        String body;
        String orderContent;

        //gets the user inputted email address and set to string
        userEmailString = userEmail.getText().toString();

        //string setting the subject for the email
        subject = "ECommerce TCA Order Email";
        //gets the basket and sets it as the content
        orderContent = basket.getText().toString();

        //sets the body as a welcome message with instructions on what to do next as well as combining
        //the dertails
        body = "Thank you for your order, We aim to dispatch your order within three working days."
        + "\n" + "Please save/send this email to keep a copy of your order" + "\n"
        + "Order Details: " + "\n" + orderContent;

        //creates the intent for the email and assigns values that are used forthe email, subject and body
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_EMAIL, new String[]{userEmailString});
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_TEXT, body);
        //sets the type to ensure that only compatible apps are called
        intent.setType("message/rfc822");
        if(intent.resolveActivity(getPackageManager()) != null){
            startActivity(intent);
        }
        //if no compatible email apps are called then a toast message is displayed letting the user know
        else{
            Toast.makeText(this, "No Compatible Email Application Found", Toast.LENGTH_SHORT).show();
        }
    }
}